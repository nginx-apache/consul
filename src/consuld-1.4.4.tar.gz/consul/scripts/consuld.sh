#!/bin/sh
# chkconfig:   2345 90 10
# description:  consul
# Centos 6.*

EXEC=/usr/local/consul/bin/consul
PIDFILE=/var/run/consul.pid
BIND="0.0.0.0"
CONFIG_DIR=/usr/local/consul/config
STARTPARAMS="agent -config-dir=$CONFIG_DIR"

case "$1" in
    start)
        echo -n "Starting consuld "
        if [ -f $PIDFILE ]
        then
                echo "$PIDFILE exists, process is already running or crashed"
        else
                $EXEC $STARTPARAMS -bind=$BIND -pid-file=$PIDFILE >/dev/null 2>&1 &
        fi
        ;;
    stop)
        echo -n "Gracefully shutting down consuld"
        if [ ! -f $PIDFILE ]
        then
                echo "$PIDFILE does not exist, process is not running"
        else
                PID=$(cat $PIDFILE)
                kill -INT $PID
                echo "Stopping ..."
                while [ -x /proc/${PID} ]
                do
                    echo "Waiting for consul to shutdown ..."
                    sleep 1
                done
                echo "consuld stopped"
        fi
        ;;
    reload)
        echo  "Reload consuld config"
        $EXEC reload
        ;;
    restart)
	$0 stop
	$0 start
        ;;
    *)
        echo "Usage: $0 {start|stop|reload|restart}"
        ;;
esac
